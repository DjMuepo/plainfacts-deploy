# v65 Regenerated - Launch Layer

Includes:
- invite registry backend
- invite validation / redemption
- invite screen
- onboarding screen
- landing funnel screen
- admin invite management screen
