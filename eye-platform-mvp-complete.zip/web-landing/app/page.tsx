import React from 'react';

export default function Home() {
  return (
    <main className="page">
      <div className="wrap">
        <div className="panel">
          <h1 className="title">Eye Platform</h1>
          <p className="subtitle">AI-guided 3D design, sharing, and nearby printing.</p>
        </div>
      </div>
    </main>
  );
}
