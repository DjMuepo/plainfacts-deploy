# Object Discovery Radar

Implemented in v56.

Purpose:
Provide a unified discovery interface for nearby:
- objects to scan
- broken objects to repair
- scan missions
- available printers

Endpoint:
POST /v1/radar/discovery
