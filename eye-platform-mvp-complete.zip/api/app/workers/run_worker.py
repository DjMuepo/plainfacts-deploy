from app.workers.executor import run_once

if __name__ == '__main__':
    print(run_once())
