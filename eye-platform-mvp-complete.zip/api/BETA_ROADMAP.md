
# Path to Beta

Implemented in v42:
- Preview generation for shared designs
- Remix design endpoint
- Foundation for OpenGraph preview cards

Next tasks before Beta:
1. Deploy preview storage to cloud (S3/R2)
2. Add universal deep links
3. Printer node status service
4. Production database migration
