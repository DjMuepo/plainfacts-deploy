# v61 UI Auto-write + AI Learning

## Implemented
- AI learning summary service and endpoint
- mobile learning screen
- flow actions screen for accepted scan, edit append, and print complete

## New endpoint
- GET /v1/ai/learning-summary
