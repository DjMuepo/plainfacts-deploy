# v64 Regenerated - Monetization + Behavior Engine

Includes:
- ghost save flow
- free-session exit warning
- one-time recovery
- first print success prompt
- gold orb premium marker concept
- behavior event logging
