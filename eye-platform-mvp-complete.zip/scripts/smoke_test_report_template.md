# Smoke Test Report

Date:
Tester:
Environment:

## Results
- Publish/share:
- Deep links:
- Community:
- Auth:
- Printer:
- Queue/worker:
- Web landing:
- API health:

## Issues found
1.
2.
3.

## Launch recommendation
- [ ] Ready for closed beta
- [ ] Needs fixes before beta
