# AR Object Placement

## Implemented in v57
- AR placement planning service
- `/v1/ar/placement-plan` endpoint
- mobile AR placement planning screen

## Purpose
Preview object placement in the real world before printing so users can check:
- fit
- scale
- angle
- clearance
- stability
