# v62 Premium Auto-Save Gating

## Implemented
- subscription gate check service
- auto-save eligibility endpoint
- premium auto-save screen

## New endpoint
- POST /v1/subscription/auto-save-check

## Product behavior
- free users can still use scan, fix, AR, and print tools
- automatic Object DNA save is reserved for paid accounts
- paid users can auto-save accepted scan, fix, and AR actions into Object DNA
